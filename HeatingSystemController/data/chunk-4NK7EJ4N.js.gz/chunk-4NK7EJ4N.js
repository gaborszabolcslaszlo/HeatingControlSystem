var e={production:!1,deviceWsSocket:!1,deviceApiconnect:!0,updateApiInterval:5e3};export{e as a};
